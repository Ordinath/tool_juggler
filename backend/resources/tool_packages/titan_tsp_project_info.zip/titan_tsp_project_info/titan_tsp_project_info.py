from requests_oauthlib import OAuth1Session
from langchain.agents import Tool
# get_secret_value is the function to be used within all tool components to get secrets
from utils import get_secret_value


def titan_tsp_project_information_tool(projectnumber):

    url = "https://5515123-sb1.restlets.api.netsuite.com/app/site/hosting/restlet.nl?script=4174&deploy=1&searchid=16010&projectnumber=" + projectnumber

    netsuite_session = OAuth1Session(
        client_key=get_secret_value("NS_CLIENT_KEY"),
        client_secret=get_secret_value("NS_CLIENT_SECRET"),
        resource_owner_key=get_secret_value("NS_RESOURCE_OWNER_KEY"),
        resource_owner_secret=get_secret_value("NS_RESOURCE_OWNER_SECRET"),
        realm=get_secret_value("NS_REALM"),
        signature_method='HMAC-SHA256')

    r = netsuite_session.get(
        url, headers={'Content-Type': 'application/json'})
    print(r.text)
    return r.text


def get_tool(app):
    return Tool(
        name="Titan TSP Project Information",
        func=titan_tsp_project_information_tool,
        description="useful for when you need to get more information about a specific Titan TSP# project. The input should be 'TSP[number]' ex: TSP123456."
    ),
